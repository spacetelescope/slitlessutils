from .polyclip import multi,single
