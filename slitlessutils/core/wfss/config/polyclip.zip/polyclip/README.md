Polyclip
--------
This is the python and C files to call the functions written in the ```polyclip.c``` file, written by JD Smith at University of Toledo.


